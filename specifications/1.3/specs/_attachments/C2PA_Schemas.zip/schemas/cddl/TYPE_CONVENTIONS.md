# Typographical Conventions

| type trait | example | typo convention |
-------------|---------|-----------------|
| extensible type choice | `int / text / ...` | `$`NAME`-type-choice` |
| closed type choice | `int / text` | NAME`-type-choice` |
| group choice | `( 1 : int // 2 : text )` | `$$`NAME`-group-choice` |
| group | `( 1 : int, 2 : text )` | NAME`-group` |
| type | `int` | NAME`-type`|
| tagged type | `#6.123(int)` | `tagged-`NAME`-type`|
| map | `{ 1 : int, 2 : text }` | NAME-`map` |
| array | `[ 1 : int, 2 : text ]` | NAME-`array` |
| flags | `&( a: 1, b: 2 )` | NAME-`flags` |
