# Validation

To test the validation of these schemas against their examples, you will need:

* `cddl` (`gem install cddl`)
* `diag2cbor.rb` (`gem install cbor-diag`)
* `make`

From this directory, run `make`.

## Adding New Definitions Or Examples

The Makefile has a list, defined in a variable called `STANDALONE_CDDL`, which tracks the CDDL files in this directory that should be included in validation. For each file included in this list, the Makefile will also check for a similarly named file in the `examples` directory, but with a `.cbordiag` extension instead of `.cddl`. Please ensure both CDDL and CBOR-Diag example file are present before adding a CDDL file with `STANDALONE_CDDL += EXAMPLE_FILE.cddl`.

There are another set of files in another variable called `COMMON_CDDL`. These files are where common reusable definitions should live. The Makefile will take all the files in the `COMMON_CDDL` variable, concatenate them together, and add them to the end of each `STANDALONE_CDDL` file that is being validated.

## Checking CDDL Validity

The default `make` goal of `validate` checks that example CBOR-Diag files validate against their CDDL schemas. The Makefile includes another goal, `make check` that checks the well-formedness / validity of all CDDL files in this directory, which can be useful when writing CDDL files that do not currently have examples.