# Validation

To test the validation of these schemas against their examples, you will need:

* `jq` (https://stedolan.github.io/jq/)
* `ajv` (https://github.com/ajv-validator/ajv-cli)
* `make`

## Running Make

With the above dependencies installed, run `make` from this directory.

## Individual File Validation

From this directory, run `jq '.examples[0]' < ${SCHEMA_FILE} | ajv -s ${SCHEMA_FILE} -d /dev/stdin`, where `${SCHEMA_FILE}` is the file in this directory you want to validate. 

If you are validating a schema with referenced schemas (i.e. it uses the `$ref` keyword), then you'll need to also include those referenced schemas in your command-line invocation. Suffix the above command with `-r "referenced/*"` to add all the referenced schemas.